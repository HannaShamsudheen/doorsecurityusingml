import cv2
import os


face_classifier = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
path="dataset\\"

def detection1(Id):
    video_capture = cv2.VideoCapture(0)
    count=0

    while True:

        result, video_frame = video_capture.read()  # read frames from the video
        if result is False:
            break  # terminate the loop if the frame is not read successfully

    #     faces = detect_bounding_box(video_frame,name)  # apply the function we created to the video frame
        gray_image = cv2.cvtColor(video_frame, cv2.COLOR_BGR2GRAY)
        faces = face_classifier.detectMultiScale(gray_image, 1.1, 5, minSize=(40, 40))
        if len(faces)>1:
                print("Multiple Faces")
        else:
            for (x, y, w, h) in faces:
                     cv2.rectangle(video_frame, (x, y), (x + w, y + h), (0, 255, 0), 4)
                     face= video_frame[y:y + h, x:x + w]
                     if os.path.exists(path+str(Id)):
                         count+=1
                         cv2.imwrite(path+str(Id)+"\\"+str(count)+".jpg",face)
                     else:
                         os.mkdir(path+str(Id))
            if count>=100:
                break
        #                  cv2.imwrite(path+name+"\\"+str(count)+".jpg",face)
            cv2.imshow("My Face Detection Project", video_frame)  # display the processed frame in a window named "My Face Detection Project"

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    video_capture.release()
    cv2.destroyAllWindows()
